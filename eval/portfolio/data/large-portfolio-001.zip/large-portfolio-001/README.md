# Large synthetic ingestion dataset

120 properties, 240 tenants, 30 landlords, 36 providers, 480 repair tickets and 3,288 source files. All records are synthetic.

The source data is unchanged from the validated generation. Manifest hashes cover the ordered input sources and their ingestion metadata.

Use the self-contained tools in the platform repository:

    python3 eval/portfolio_data.py validate --pack .artifacts/large-portfolio-001
    uv run --locked python eval/portfolio_data.py ingest --pack .artifacts/large-portfolio-001 --platform-root . --out .artifacts/portfolio-check --save-state

See eval/portfolio/README.md in the repository for complete instructions. The archive is data, not a standalone Python application.

Only sources/ and import/ are ingestion material. Keep evaluator-only/ out of agent context and retrieval. This is a historical portfolio snapshot containing known outcomes, not a blind agent benchmark.

RESULTS.json records the original validation; detailed reports are included in the repository under eval/portfolio/results/. Every source passed property-batch ingestion and five properties passed a combined import. The whole portfolio was not imported into one shared database in that validation.
