# Supplied CRM relationships

[
  {
    "source": "person:landlord-0003",
    "target": "property:property-0003",
    "relation": "owns",
    "attributes": {
      "share_pct": 100
    }
  },
  {
    "source": "company:portfolio-agency",
    "target": "property:property-0003",
    "relation": "manages",
    "attributes": {}
  },
  {
    "source": "person:tenant-0005",
    "target": "property:property-0003",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": true
    }
  },
  {
    "source": "person:tenant-0006",
    "target": "property:property-0003",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": false
    }
  }
]
