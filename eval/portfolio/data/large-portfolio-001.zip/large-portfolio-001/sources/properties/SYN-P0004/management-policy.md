# Management instruction for SYN-P0004
Landlord: Sofia Okafor (landlord.0004@portfolio.example.test).
Diagnostic attendance is allowed up to £100 including tax. Replacement parts require specific landlord approval.
Confirm scope, gross price and current tenant access consent. Possession of keys does not grant access.
Escalate unresolved safety concerns to the supplied duty contact; never claim a completed visit without evidence.
Duty contact: operations@portfolio.example.test (synthetic only).
