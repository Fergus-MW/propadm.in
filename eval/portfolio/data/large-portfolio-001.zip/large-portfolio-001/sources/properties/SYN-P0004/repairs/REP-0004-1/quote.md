# Quote Q-0004-1
Property: SYN-P0004
Provider: Elm Damp/Mould 018
Scope: Investigate and address: damp patch beside bedroom window
Total gross: £270.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
