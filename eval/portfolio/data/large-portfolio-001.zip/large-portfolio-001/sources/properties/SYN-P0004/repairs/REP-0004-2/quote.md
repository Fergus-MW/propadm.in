# Quote Q-0004-2
Property: SYN-P0004
Provider: Orchard Electrical 015
Scope: Investigate and address: kitchen socket intermittently trips
Total gross: £285.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
