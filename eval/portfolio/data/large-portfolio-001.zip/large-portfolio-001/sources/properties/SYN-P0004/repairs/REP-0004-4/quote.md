# Quote Q-0004-4
Property: SYN-P0004
Provider: Elm General Building 024
Scope: Investigate and address: loose plaster after historic leak
Total gross: £315.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
