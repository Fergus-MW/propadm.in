# Quote Q-0005-1
Property: SYN-P0005
Provider: Beacon Appliance Repair 028
Scope: Investigate and address: washing machine stops mid-cycle
Total gross: £330.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
