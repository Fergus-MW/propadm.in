# Quote Q-0005-3
Property: SYN-P0005
Provider: Willow Plumbing 025
Scope: Investigate and address: water beneath kitchen sink
Total gross: £105.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
