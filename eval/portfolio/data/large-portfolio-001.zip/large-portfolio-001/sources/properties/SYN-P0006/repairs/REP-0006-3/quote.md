# Quote Q-0006-3
Property: SYN-P0006
Provider: Cedar Gardening 032
Scope: Investigate and address: communal garden gate damaged
Total gross: £165.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
