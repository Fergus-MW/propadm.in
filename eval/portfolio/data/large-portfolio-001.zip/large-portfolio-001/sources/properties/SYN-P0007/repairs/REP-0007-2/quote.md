# Quote Q-0007-2
Property: SYN-P0007
Provider: Cedar Heating/Gas 002
Scope: Investigate and address: boiler loses pressure
Total gross: £210.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
