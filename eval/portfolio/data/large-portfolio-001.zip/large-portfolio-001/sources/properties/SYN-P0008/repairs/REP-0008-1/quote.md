# Quote Q-0008-1
Property: SYN-P0008
Provider: Elm Damp/Mould 006
Scope: Investigate and address: damp patch beside bedroom window
Total gross: £255.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
