# Quote Q-0008-3
Property: SYN-P0008
Provider: Cedar Gardening 008
Scope: Investigate and address: communal garden gate damaged
Total gross: £285.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
