# Quote Q-0010-3
Property: SYN-P0010
Provider: Cedar Gardening 020
Scope: Investigate and address: communal garden gate damaged
Total gross: £150.00
Valid until: 2026-10-08
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
