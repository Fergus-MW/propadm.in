# Quote Q-0011-3
Property: SYN-P0011
Provider: Willow Plumbing 025
Scope: Investigate and address: water beneath kitchen sink
Total gross: £210.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
