# Supplied CRM relationships

[
  {
    "source": "person:landlord-0013",
    "target": "property:property-0013",
    "relation": "owns",
    "attributes": {
      "share_pct": 100
    }
  },
  {
    "source": "company:portfolio-agency",
    "target": "property:property-0013",
    "relation": "manages",
    "attributes": {}
  },
  {
    "source": "person:tenant-0025",
    "target": "property:property-0013",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": true
    }
  },
  {
    "source": "person:tenant-0026",
    "target": "property:property-0013",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": false
    }
  }
]
