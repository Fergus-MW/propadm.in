# Quote Q-0013-1
Property: SYN-P0013
Provider: Beacon Appliance Repair 004
Scope: Investigate and address: washing machine stops mid-cycle
Total gross: £300.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
