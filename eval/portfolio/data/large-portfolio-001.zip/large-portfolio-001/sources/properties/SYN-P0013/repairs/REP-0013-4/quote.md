# Quote Q-0013-4
Property: SYN-P0013
Provider: Moor Locksmith 005
Scope: Investigate and address: front door latch sticks
Total gross: £90.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
