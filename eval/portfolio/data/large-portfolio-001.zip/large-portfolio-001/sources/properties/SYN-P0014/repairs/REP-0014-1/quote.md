# Quote Q-0014-1
Property: SYN-P0014
Provider: Elm Damp/Mould 006
Scope: Investigate and address: damp patch beside bedroom window
Total gross: £105.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
