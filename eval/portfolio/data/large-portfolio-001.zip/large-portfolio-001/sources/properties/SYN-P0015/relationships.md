# Supplied CRM relationships

[
  {
    "source": "person:landlord-0015",
    "target": "property:property-0015",
    "relation": "owns",
    "attributes": {
      "share_pct": 75
    }
  },
  {
    "source": "company:portfolio-agency",
    "target": "property:property-0015",
    "relation": "manages",
    "attributes": {}
  },
  {
    "source": "person:landlord-0016",
    "target": "property:property-0015",
    "relation": "owns",
    "attributes": {
      "share_pct": 25
    }
  },
  {
    "source": "person:tenant-0029",
    "target": "property:property-0015",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": true
    }
  },
  {
    "source": "person:tenant-0030",
    "target": "property:property-0015",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": false
    }
  }
]
