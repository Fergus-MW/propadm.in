# Quote Q-0015-3
Property: SYN-P0015
Provider: Willow Plumbing 013
Scope: Investigate and address: water beneath kitchen sink
Total gross: £195.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
