# Quote Q-0016-2
Property: SYN-P0016
Provider: Orchard Electrical 015
Scope: Investigate and address: kitchen socket intermittently trips
Total gross: £240.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
