# Quote Q-0017-4
Property: SYN-P0017
Provider: Moor Locksmith 029
Scope: Investigate and address: front door latch sticks
Total gross: £330.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
