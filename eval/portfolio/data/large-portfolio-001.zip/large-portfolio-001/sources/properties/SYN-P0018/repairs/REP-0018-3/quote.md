# Quote Q-0018-3
Property: SYN-P0018
Provider: Cedar Gardening 032
Scope: Investigate and address: communal garden gate damaged
Total gross: £120.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
