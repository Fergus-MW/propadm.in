# Quote Q-0018-4
Property: SYN-P0018
Provider: Elm General Building 036
Scope: Investigate and address: loose plaster after historic leak
Total gross: £135.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
