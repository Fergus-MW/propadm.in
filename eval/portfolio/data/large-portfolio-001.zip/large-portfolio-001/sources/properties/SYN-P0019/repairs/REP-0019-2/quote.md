# Quote Q-0019-2
Property: SYN-P0019
Provider: Cedar Heating/Gas 002
Scope: Investigate and address: boiler loses pressure
Total gross: £165.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
