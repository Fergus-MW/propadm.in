# Quote Q-0019-3
Property: SYN-P0019
Provider: Willow Plumbing 001
Scope: Investigate and address: water beneath kitchen sink
Total gross: £180.00
Valid until: 2026-10-08
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
