# Quote Q-0019-4
Property: SYN-P0019
Provider: Moor Locksmith 005
Scope: Investigate and address: front door latch sticks
Total gross: £195.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
