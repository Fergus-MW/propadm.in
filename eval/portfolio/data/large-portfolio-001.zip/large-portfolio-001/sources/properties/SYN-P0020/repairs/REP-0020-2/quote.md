# Quote Q-0020-2
Property: SYN-P0020
Provider: Orchard Electrical 003
Scope: Investigate and address: kitchen socket intermittently trips
Total gross: £225.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
