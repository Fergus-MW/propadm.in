# Quote Q-0020-3
Property: SYN-P0020
Provider: Cedar Gardening 008
Scope: Investigate and address: communal garden gate damaged
Total gross: £240.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
