# Quote Q-0020-4
Property: SYN-P0020
Provider: Elm General Building 012
Scope: Investigate and address: loose plaster after historic leak
Total gross: £255.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
