# Quote Q-0023-2
Property: SYN-P0023
Provider: Cedar Heating/Gas 026
Scope: Investigate and address: boiler loses pressure
Total gross: £150.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
