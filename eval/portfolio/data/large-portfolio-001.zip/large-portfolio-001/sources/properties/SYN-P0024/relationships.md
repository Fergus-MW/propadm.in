# Supplied CRM relationships

[
  {
    "source": "person:landlord-0024",
    "target": "property:property-0024",
    "relation": "owns",
    "attributes": {
      "share_pct": 100
    }
  },
  {
    "source": "company:portfolio-agency",
    "target": "property:property-0024",
    "relation": "manages",
    "attributes": {}
  },
  {
    "source": "person:tenant-0047",
    "target": "property:property-0024",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": true
    }
  },
  {
    "source": "person:tenant-0048",
    "target": "property:property-0024",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": false
    }
  }
]
