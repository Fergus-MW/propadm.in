# Quote Q-0024-1
Property: SYN-P0024
Provider: Elm Damp/Mould 030
Scope: Investigate and address: damp patch beside bedroom window
Total gross: £195.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
