# Quote Q-0024-2
Property: SYN-P0024
Provider: Orchard Electrical 027
Scope: Investigate and address: kitchen socket intermittently trips
Total gross: £210.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
