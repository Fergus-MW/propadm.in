# Supplied CRM relationships

[
  {
    "source": "person:landlord-0025",
    "target": "property:property-0025",
    "relation": "owns",
    "attributes": {
      "share_pct": 75
    }
  },
  {
    "source": "company:portfolio-agency",
    "target": "property:property-0025",
    "relation": "manages",
    "attributes": {}
  },
  {
    "source": "person:landlord-0026",
    "target": "property:property-0025",
    "relation": "owns",
    "attributes": {
      "share_pct": 25
    }
  },
  {
    "source": "person:tenant-0049",
    "target": "property:property-0025",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": true
    }
  },
  {
    "source": "person:tenant-0050",
    "target": "property:property-0025",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": false
    }
  }
]
