# Quote Q-0026-2
Property: SYN-P0026
Provider: Orchard Electrical 003
Scope: Investigate and address: kitchen socket intermittently trips
Total gross: £330.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
