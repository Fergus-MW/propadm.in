# Supplied CRM relationships

[
  {
    "source": "person:landlord-0027",
    "target": "property:property-0027",
    "relation": "owns",
    "attributes": {
      "share_pct": 100
    }
  },
  {
    "source": "company:portfolio-agency",
    "target": "property:property-0027",
    "relation": "manages",
    "attributes": {}
  },
  {
    "source": "person:tenant-0053",
    "target": "property:property-0027",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": true
    }
  },
  {
    "source": "person:tenant-0054",
    "target": "property:property-0027",
    "relation": "tenant_of",
    "attributes": {
      "from": "2026-05-01",
      "to": "2027-04-30",
      "is_lead_tenant": false
    }
  }
]
