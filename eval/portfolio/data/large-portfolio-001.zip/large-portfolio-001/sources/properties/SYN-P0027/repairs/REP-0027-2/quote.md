# Quote Q-0027-2
Property: SYN-P0027
Provider: Cedar Heating/Gas 014
Scope: Investigate and address: boiler loses pressure
Total gross: £135.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
