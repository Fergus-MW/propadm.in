# Quote Q-0027-4
Property: SYN-P0027
Provider: Moor Locksmith 017
Scope: Investigate and address: front door latch sticks
Total gross: £165.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
