# Quote Q-0028-4
Property: SYN-P0028
Provider: Elm General Building 024
Scope: Investigate and address: loose plaster after historic leak
Total gross: £225.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
