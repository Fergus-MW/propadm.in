# Quote Q-0029-1
Property: SYN-P0029
Provider: Beacon Appliance Repair 028
Scope: Investigate and address: washing machine stops mid-cycle
Total gross: £240.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
