# Quote Q-0029-2
Property: SYN-P0029
Provider: Cedar Heating/Gas 026
Scope: Investigate and address: boiler loses pressure
Total gross: £255.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
