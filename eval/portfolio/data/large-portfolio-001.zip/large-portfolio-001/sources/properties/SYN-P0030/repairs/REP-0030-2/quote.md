# Quote Q-0030-2
Property: SYN-P0030
Provider: Orchard Electrical 027
Scope: Investigate and address: kitchen socket intermittently trips
Total gross: £315.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
