# Quote Q-0033-1
Property: SYN-P0033
Provider: Beacon Appliance Repair 016
Scope: Investigate and address: washing machine stops mid-cycle
Total gross: £225.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
