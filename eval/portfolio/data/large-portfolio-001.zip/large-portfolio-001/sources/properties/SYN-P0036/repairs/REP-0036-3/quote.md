# Quote Q-0036-3
Property: SYN-P0036
Provider: Cedar Gardening 032
Scope: Investigate and address: communal garden gate damaged
Total gross: £180.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
