# Quote Q-0036-4
Property: SYN-P0036
Provider: Elm General Building 036
Scope: Investigate and address: loose plaster after historic leak
Total gross: £195.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
