# Quote Q-0038-4
Property: SYN-P0038
Provider: Elm General Building 012
Scope: Investigate and address: loose plaster after historic leak
Total gross: £315.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
