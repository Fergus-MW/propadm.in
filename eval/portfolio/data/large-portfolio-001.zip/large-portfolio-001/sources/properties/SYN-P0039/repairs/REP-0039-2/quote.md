# Quote Q-0039-2
Property: SYN-P0039
Provider: Cedar Heating/Gas 014
Scope: Investigate and address: boiler loses pressure
Total gross: £90.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
