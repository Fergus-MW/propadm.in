# Quote Q-0040-2
Property: SYN-P0040
Provider: Orchard Electrical 015
Scope: Investigate and address: kitchen socket intermittently trips
Total gross: £150.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
