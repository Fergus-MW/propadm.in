# Quote Q-0042-1
Property: SYN-P0042
Provider: Elm Damp/Mould 030
Scope: Investigate and address: damp patch beside bedroom window
Total gross: £255.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
