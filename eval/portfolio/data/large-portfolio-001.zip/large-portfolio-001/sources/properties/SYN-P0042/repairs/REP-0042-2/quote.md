# Quote Q-0042-2
Property: SYN-P0042
Provider: Orchard Electrical 027
Scope: Investigate and address: kitchen socket intermittently trips
Total gross: £270.00
Valid until: 2026-10-20
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
