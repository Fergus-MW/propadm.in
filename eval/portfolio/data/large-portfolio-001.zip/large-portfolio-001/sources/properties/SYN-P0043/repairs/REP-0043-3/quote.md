# Quote Q-0043-3
Property: SYN-P0043
Provider: Willow Plumbing 001
Scope: Investigate and address: water beneath kitchen sink
Total gross: £90.00
Valid until: 2026-10-08
Exclusions: Additional parts require a separate price and specific approval.
No appointment is implied by this quotation.
